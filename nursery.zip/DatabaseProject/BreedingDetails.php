<!DOCTYPE html>
<html>
<head>
	<style>
	table, th, td 
	{
		border: 2px solid black;
	}
	table 
	{

		width: 100%;
border-collapse: collapse;
	}
	td 
	{
		text-align: center;
	}
	</style>
</head>
<body>
<table>
	 <?php
$db=mysqli_connect('localhost','root','','a');
$result=mysqli_query($db, "SELECT * FROM storing");
?>
<link rel="stylesheet" href="sty.css" />
<div class="table">
    <thead> 
     <tr>
       <th>Plant Name</th>
       <th>Plant Type</th>
      <th>Arrival Date</th>
      <th>Quantity</th>
       <th>Storage Location</th>
	   <th>Time Required</th>
    </tr>
   </thead>
   <?php
   while($row= $result->fetch_assoc()):?>
    <tr>
    <td> <?php echo $row['plantname'];?></td>
     <td> <?php echo $row['planttype'];?></td>
     <td> <?php echo $row['arrivaldate'];?></td>
     <td> <?php echo $row['quantity'];?></td>
     <td> <?php echo $row['storagelocation'];?></td>
     <td> <?php echo $row['timerequired'];?></td>
     </tr>
    <?php endwhile; ?>


   </table>
</div>
	
</table>
</body>
</html>
<a href="index.php">Back to home</a>
</div>