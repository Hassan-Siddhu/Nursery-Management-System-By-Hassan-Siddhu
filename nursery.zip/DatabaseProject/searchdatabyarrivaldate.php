<html>
<head>
<style>
	table, th, td 
	{
		border: 2px solid black;
	}
	table 
	{
		width: 100%;
		border-collapse: collapse;
	}
	td 
	{
		text-align: center;
	}
	</style>
	<title> Search Data By Arrival Date </title>
</head>
<body>
	<center>
	<h1> Search Data By Arrival Date </h1>
	
	<div class="container">
	<form action="" method="POST">
	<input type="date" name="arrivaldate" placeholder="Enter Arrival Date">
	<input type="submit" name="Search" placeholder="Search By Arrival Date">
	</form>
	<table>
	<link rel="stylesheet" href="sty.css" />
		<div class="table"> 
			<tr>
				
				<th>Plant Name</th>
				<th>Plant Type</th>
				<th>Arrival Date</th>
				<th>Quantity</th>
				<th>Storage Location</th>
                <th>Time Required</th>

			</tr>
		</div>

			<?php
				$db = mysqli_connect('localhost','root','','a');

				if(isset($_POST['Search']))
				{
					$arrivaldate      = $_POST['arrivaldate'];
					$sql= "SELECT * FROM storing where arrivaldate='$arrivaldate'";
					$result = mysqli_query($db, $sql);
				while($row= mysqli_fetch_array($result))
				{
					?>
					    <tr>
					    
					    <td> <?php echo $row['plantname'];?></td>
					    <td> <?php echo $row['planttype'];?></td>
					    <td> <?php echo $row['arrivaldate'];?></td>
					    <td> <?php echo $row['quantity'];?></td>
					    <td> <?php echo $row['storagelocation'];?></td>
                        <td> <?php echo $row['timerequired'];?></td>
					    </tr>
					
						<?php
				}
			}
			?>
	</table>
	</center>
</body>
<a href="Searchfromstoring.php"> Back to Search </a>
</html>