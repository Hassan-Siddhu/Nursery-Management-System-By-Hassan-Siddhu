<link rel="stylesheet" href="sty.css" />
<div class="header">
<style>
img
{
border: 1px solid #ddd;
  border-radius: 4px;
  padding: 5px;
  width: 250px;
}
.button {​​​​
    background-color:#367777;
    border-radius:28px;
    border:1px solid #215151;
    display:inline-block;
    cursor:pointer;
    color:#ffffff;
    font-family:Arial;
    font-size:13px;
    padding:12px 31px;
    text-decoration:none;
    text-shadow:0px 1px 0px #2f6627;
}​​​​
.button:hover {​​​​
    background-color:#009680;
}​​​​
.button:active {​​​​
    position:relative;
    top:1px;
}​​​​
.button1 {​​​​
    background-color:#000000;
    border-radius:28px;
    border:1px solid #215151;
    display:inline-block;
    cursor:pointer;
    color:#ffffff;
    font-family:Arial;
    font-size:13px;
    padding:12px 31px;
    text-decoration:none;
    text-shadow:0px 1px 0px #2f6627;
}​​​​
.button1:hover {​​​​
    background-color:#009680;
}​​​​
.button1:active {​​​​
    position:relative;
    top:1px;
}​​​​
input {​​​​
  background-color: white;
  color: white;
}​​​​
</style>
<h1>Add Purchasing Details</h1>
<img src="Nursery.jpeg">
    <form action="server.php" method="post">
		<br>	<label for="purchasedfrom">Purchased From</label><br>
        <input type="text" name="purchasedfrom" id="purchasedfrom">
		
		<br>	<label for="plantname">Plant Name</label><br>
    	<input type="text" name="plantname" id="plantname">
		
		<br>	<label for="planttype">Plant Type</label><br>
    	<input type="text" name="planttype" id="planttype">
		
		<br>	<label for="price">Price</label><br>
    	<input type="number" name="price" id="price">
		
		<br>	<label for="quantity">Quantity</label><br>
    	<input type="number" name="quantity" id="quantity">
		
		<br>	<label for="purchasingdate">Purchasing Date</label><br>
    	<input type="date" name="purchasingdate" id="purchasingdate">
		<br>
		
		<br>    <input type="submit" class="button" id="Add" name="Add" value="Add">
		<input type="submit" class="button" id="Update" name="Update" value="Update"> 
        <input type="submit" class="button" id="Delete" name="Delete" value="Delete"> 
    
    </form>

  <a href="index.php">Back to home</a>
    </div>