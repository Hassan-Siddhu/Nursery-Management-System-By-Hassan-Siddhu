<html>
<head>
<style>
	table, th, td 
	{
		border: 2px solid black;
	}
	table 
	{
		width: 100%;
		border-collapse: collapse;
	}
	td 
	{
		text-align: center;
	}
	</style>
	<title> Search Data By Purchasing Date </title>
</head>
<body>
	<center>
	<h1> Search Data By Purchasing Date </h1>
	
	<div class="container">
	<form action="" method="POST">
	<input type="date" name="purchasingdate" placeholder="Enter Purchasing Date">
	<input type="submit" name="Search" placeholder="Search By Purchasing Date">
	</form>
	<table>
	<link rel="stylesheet" href="sty.css" />
		<div class="table"> 
			<tr>
				<th>Purchased From</th>
				<th>Plant Name</th>
				<th>Plant Type</th>
				<th>Price</th>
				<th>Quantity</th>
				<th>Purchasing Date</th>
			</tr>
		</div>

			<?php
				$db = mysqli_connect('localhost','root','','a');

				if(isset($_POST['Search']))
				{
					$purchasingdate      = $_POST['purchasingdate'];
					$sql= "SELECT * FROM purchasing where purchasingdate='$purchasingdate'";
					$result = mysqli_query($db, $sql);
				while($row= mysqli_fetch_array($result))
				{
					?>
					    <tr>
					    <td> <?php echo $row['purchasedfrom'];?></td>
					    <td> <?php echo $row['plantname'];?></td>
					    <td> <?php echo $row['planttype'];?></td>
					    <td> <?php echo $row['price'];?></td>
					    <td> <?php echo $row['quantity'];?></td>
					    <td> <?php echo $row['purchasingdate'];?></td>
					    </tr>
					
						<?php
				}
			}
			?>
	</table>
	</center>
</body>
<a href="Searchfrompurchasing.php"> Back to Search </a>
</html>