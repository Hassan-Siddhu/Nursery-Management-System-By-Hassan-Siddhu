<!DOCTYPE html>
<html>
<head>
	<style>
	table, th, td 
	{
		border: 2px solid black;
	}
	table 
	{
		width: 100%;
border-collapse: collapse;
	}
	td 
	{
		text-align: center;
	}
	</style>
</head>
<body>
<table>
	 <?php
$db=mysqli_connect('localhost','root','','a');
$result=mysqli_query($db, "SELECT * FROM purchasing");
?>
<link rel="stylesheet" href="sty.css" />
<div class="table">
    <thead> 
     <tr>
       <th>Purchased From</th>
       <th>Plant Name</th>
       <th>Plant Type</th>
      <th>Price</th>
      <th>Quantity</th>
       <th>Purchasing Date</th>
    </tr>
   </thead>
   <?php
   while($row= $result->fetch_assoc()):?>
    <tr>
    <td> <?php echo $row['purchasedfrom'];?></td>
    <td> <?php echo $row['plantname'];?></td>
     <td> <?php echo $row['planttype'];?></td>
     <td> <?php echo $row['price'];?></td>
     <td> <?php echo $row['quantity'];?></td>
     <td> <?php echo $row['purchasingdate'];?></td>
    
     </tr>
    <?php endwhile; ?>
   </table>
</div>
	
</table>
</body>
</html>
<a href="index.php">Back to home</a>
</div>