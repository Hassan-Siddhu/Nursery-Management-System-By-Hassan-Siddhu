<html>
<head>
<style>
	table, th, td 
	{
		border: 2px solid black;
	}
	table 
	{
		width: 100%;
		border-collapse: collapse;
	}
	td 
	{
		text-align: center;
	}
	</style>
	<title> Search Data By Plant Type </title>
</head>
<body>
	<center>
	<h1> Search Data By Plant Type </h1>
	
	<div class="container">
	<form action="" method="POST">
	<input type="text" name="planttype" placeholder="Enter Plant Type">
	<input type="submit" name="Search" placeholder="Search By Plant Type">
	</form>
	<table>
	<link rel="stylesheet" href="sty.css" />
		<div class="table"> 
			<tr>
				<th>Plant Name</th>
				<th>Plant Type</th>
				<th>Arrival Date</th>
				<th>Quantity</th>
				<th>Storage Location</th>
                <th>Time Required</th>
			</tr>
		</div>

			<?php
				$db = mysqli_connect('localhost','root','','a');

				if(isset($_POST['Search']))
				{
					$planttype      = $_POST['planttype'];
					$sql= "SELECT * FROM storing where planttype='$planttype'";
					$result = mysqli_query($db, $sql);
				while($row= mysqli_fetch_array($result))
				{
					?>
					    <tr>

					    <td> <?php echo $row['plantname'];?></td>
					    <td> <?php echo $row['planttype'];?></td>
					    <td> <?php echo $row['arrivaldate'];?></td>
					    <td> <?php echo $row['quantity'];?></td>
					    <td> <?php echo $row['storagelocation'];?></td>
                        <td> <?php echo $row['timerequired'];?></td>
					    </tr>
					
						<?php
				}
			}
			?>
	</table>
	</center>
</body>
<a href="Searchfromstoring.php"> Back to Search </a>
</html>