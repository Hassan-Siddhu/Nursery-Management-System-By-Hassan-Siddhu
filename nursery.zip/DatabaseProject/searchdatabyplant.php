<html>
<head>
<style>
	table, th, td 
	{
		border: 2px solid black;
	}
	table 
	{
		width: 100%;
		border-collapse: collapse;
	}
	td 
	{
		text-align: center;
	}
	</style>
	<title> Search Data By Plant Name </title>
</head>
<body>
	<center>
	<h1> Search Data By Plant Name </h1>
	
	<div class="container">
	<form action="" method="POST">
	<input type="text" name="plantname" placeholder="Enter Plant Name">
	<input type="submit" name="Search" placeholder="Search By Plant Name">
	</form>
	<table>
	<link rel="stylesheet" href="sty.css" />
		<div class="table"> 
			<tr>
				<th>Purchased From</th>
				<th>Plant Name</th>
				<th>Plant Type</th>
				<th>Price</th>
				<th>Quantity</th>
				<th>Purchasing Date</th>
			</tr>
		</div>

			<?php
				$db = mysqli_connect('localhost','root','','a');

				if(isset($_POST['Search']))
				{
					$plantname      = $_POST['plantname'];
					$sql= "SELECT * FROM purchasing where plantname='$plantname'";
					$result = mysqli_query($db, $sql);
				while($row= mysqli_fetch_array($result))
				{
					?>
					    <tr>
					    <td> <?php echo $row['purchasedfrom'];?></td>
					    <td> <?php echo $row['plantname'];?></td>
					    <td> <?php echo $row['planttype'];?></td>
					    <td> <?php echo $row['price'];?></td>
					    <td> <?php echo $row['quantity'];?></td>
					    <td> <?php echo $row['purchasingdate'];?></td>
					    </tr>
					
						<?php
				}
			}
			?>
	</table>
	</center>
</body>
<a href="Searchfrompurchasing.php"> Back to Search </a>
</html>