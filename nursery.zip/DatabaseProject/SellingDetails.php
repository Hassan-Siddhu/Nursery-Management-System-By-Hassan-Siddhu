<!DOCTYPE html>
<html>
<head>
	<style>
	table, th, td 
	{
		border: 2px solid black;
	}
	table 
	{
		width: 100%;
border-collapse: collapse;
	}
	td 
	{
		text-align: center;
	}
	</style>
</head>
<body>
<table>
	 <?php
$db=mysqli_connect('localhost','root','','a');
$result=mysqli_query($db, "SELECT * FROM selling");
?>
<link rel="stylesheet" href="sty.css" />
<div class="table">
    <thead> 
     <tr>
       <th>Order No</th>
       <th>Plant Name</th>
       <th>Plant Type</th>
      <th>Price</th>
      <th>Quantity</th>
       <th>Selling Date</th>
    </tr>
   </thead>
   <?php
   while($row= $result->fetch_assoc()):?>
    <tr>
    <td> <?php echo $row['orderno'];?></td>
    <td> <?php echo $row['plantname'];?></td>
     <td> <?php echo $row['planttype'];?></td>
     <td> <?php echo $row['price'];?></td>
     <td> <?php echo $row['quantity'];?></td>
     <td> <?php echo $row['sellingdate'];?></td>
    
     </tr>
    <?php endwhile; ?>


   </table>
</div>
	
</table>
</body>
</html>
<a href="index.php">Back to home</a>
</div>