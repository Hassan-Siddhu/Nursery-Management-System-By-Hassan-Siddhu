<link rel="stylesheet" href="sty.css" />
<div class="header">
<style>
img
{
border: 1px solid #ddd;
  border-radius: 4px;
  padding: 5px;
  width: 250px;
}
</style>
<h1>Add Storing Details</h1>
<img src="Nursery.jpeg">
    <form action="server.php" method="post">
      <br>	<label for="plantname">Plant Name</label><br>
        <input type="text" name="plantname" id="plantname">
    <br>	<label for="planttype">Plant Type</label><br>
    	<input type="text" name="planttype" id="planttype">
    <br>	<label for="arrivaldate">Arrival Date</label><br>
    	<input type="date" name="arrivaldate" id="arrivaldate">
    <br>	<label for="quantity">Quantity</label><br>
    	<input type="number" name="quantity" id="quantity">
    <br>	<label for="storagelocation">Storage Location</label><br>
    	<input type="text" name="storagelocation" id="storagelocation">
    <br>	<label for="timerequired">Time Required</label><br>
    	<input type="text" name="timerequired" id="timerequired">
	  <br>
      <br><input type="submit" id="Store" name="Store" value="Store">
       <input type="submit" id="UpdateStoring" name="UpdateStoring" value="UpdateStoring"> 
	   <input type="submit" id="DeleteStoring" name="DeleteStoring" value="DeleteStoring">    
    </form>

  <a href="index.php">Back to home</a>
    </div>