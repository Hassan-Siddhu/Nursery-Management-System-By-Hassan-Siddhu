<?php 
  $db = mysqli_connect('localhost','root','','a');

  if(isset($_POST['Add']))
  {
    $purchasedfrom      = $_POST['purchasedfrom'];
    $plantname          = $_POST['plantname'];
    $planttype          = $_POST['planttype'];
    $price              = $_POST['price'];
    $quantity           = $_POST['quantity'];
    $date               = $_POST['purchasingdate'];
	
    $sql= "INSERT INTO purchasing(purchasedfrom,plantname,planttype,price,quantity,purchasingdate) 
            VALUES ('$purchasedfrom','$plantname','$planttype',$price,$quantity,'$date')";

    $result = mysqli_query($db, $sql);
  }
   else if(isset($_POST['Update']))
  {
    $purchasedfrom      = $_POST['purchasedfrom'];
    $plantname          = $_POST['plantname'];
    $planttype          = $_POST['planttype'];
    $price              = $_POST['price'];
    $quantity           = $_POST['quantity'];
    $date               = $_POST['purchasingdate'];

    $sql= "UPDATE purchasing SET price='$price' where purchasedfrom='$purchasedfrom' AND plantname='$plantname' AND planttype='$planttype'";
    $result = mysqli_query($db, $sql);
	$sql= "UPDATE purchasing SET price='$price' where purchasedfrom='$purchasedfrom'";
    $result = mysqli_query($db, $sql);
	$sql= "UPDATE purchasing SET price='$price' where plantname='$plantname'";
    $result = mysqli_query($db, $sql);
	$sql= "UPDATE purchasing SET price='$price' where planttype='$planttype'";
    $result = mysqli_query($db, $sql);
    $sql= "UPDATE purchasing SET quantity='$quantity' where purchasedfrom='$purchasedfrom' AND plantname='$plantname' AND planttype='$planttype'";
    $result = mysqli_query($db, $sql);
	$sql= "UPDATE purchasing SET quantity='$quantity' where purchasedfrom='$purchasedfrom'";
    $result = mysqli_query($db, $sql);
	$sql= "UPDATE purchasing SET quantity='$quantity' where plantname='$plantname'";
    $result = mysqli_query($db, $sql);
	$sql= "UPDATE purchasing SET quantity='$quantity' where planttype='$planttype'";
    $result = mysqli_query($db, $sql);
  }
  else if(isset($_POST['Delete']))
  {
    $purchasedfrom      = $_POST['purchasedfrom'];
    $plantname          = $_POST['plantname'];
    $planttype          = $_POST['planttype'];
    $price              = $_POST['price'];
    $quantity           = $_POST['quantity'];
    $date               = $_POST['purchasingdate'];

    $sql= "DELETE FROM purchasing where purchasedfrom='$purchasedfrom' AND plantname='$plantname' AND planttype='$planttype'";
    $result = mysqli_query($db, $sql);
	$sql= "DELETE FROM purchasing where purchasedfrom='$purchasedfrom'";
    $result = mysqli_query($db, $sql);
	$sql= "DELETE FROM purchasing where plantname='$plantname'";
    $result = mysqli_query($db, $sql);
	$sql= "DELETE FROM purchasing where planttype='$planttype'";
    $result = mysqli_query($db, $sql);
  }

	header("Location: index.php");
 ?>
 
 <?php
  $db = mysqli_connect('localhost','root','','a');

  if(isset($_POST['Sell']))
  {
    $orderno            = $_POST['orderno'];
    $plantname          = $_POST['plantname'];
    $planttype          = $_POST['planttype'];
    $price              = $_POST['price'];
    $quantity           = $_POST['quantity'];
    $date               = $_POST['sellingdate'];

    $sql= "INSERT INTO selling(orderno,plantname,planttype,price,quantity,sellingdate) 
            VALUES ('$orderno','$plantname','$planttype',$price,$quantity,'$date')";

    $result = mysqli_query($db, $sql);
  }
  else if(isset($_POST['UpdateSelling']))
  {
    $orderno      		= $_POST['orderno'];
    $plantname          = $_POST['plantname'];
    $planttype          = $_POST['planttype'];
    $price              = $_POST['price'];
    $quantity           = $_POST['quantity'];
    $date               = $_POST['sellingdate'];

    $sql= "UPDATE selling SET price='$price' where orderno='$orderno' AND plantname='$plantname' AND planttype='$planttype'";
    $result = mysqli_query($db, $sql);
	$sql= "UPDATE selling SET price='$price' where orderno='$orderno'";
    $result = mysqli_query($db, $sql);
	$sql= "UPDATE selling SET price='$price' where plantname='$plantname'";
    $result = mysqli_query($db, $sql);
	$sql= "UPDATE selling SET price='$price' where planttype='$planttype'";
    $result = mysqli_query($db, $sql);
    $sql= "UPDATE selling SET quantity='$quantity' where orderno='$orderno' AND plantname='$plantname' AND planttype='$planttype'";
    $result = mysqli_query($db, $sql);
	$sql= "UPDATE selling SET quantity='$quantity' where orderno='$orderno'";
    $result = mysqli_query($db, $sql);
	$sql= "UPDATE selling SET quantity='$quantity' where plantname='$plantname'";
    $result = mysqli_query($db, $sql);
	$sql= "UPDATE selling SET quantity='$quantity' where planttype='$planttype'";
    $result = mysqli_query($db, $sql);
  }
  else if(isset($_POST['DeleteSelling']))
  {
    $orderno            = $_POST['orderno'];
    $plantname          = $_POST['plantname'];
    $planttype          = $_POST['planttype'];
    $price              = $_POST['price'];
    $quantity           = $_POST['quantity'];
    $date               = $_POST['sellingdate'];

    $sql= "DELETE FROM selling where orderno='$orderno' AND plantname='$plantname' AND planttype='$planttype'";
    $result = mysqli_query($db, $sql);
	$sql= "DELETE FROM selling where orderno='$orderno'";
    $result = mysqli_query($db, $sql);
	$sql= "DELETE FROM selling where plantname='$plantname'";
    $result = mysqli_query($db, $sql);
	$sql= "DELETE FROM selling where planttype='$planttype'";
    $result = mysqli_query($db, $sql);
  }

	header("Location: index.php");
 ?>
 
  <?php
  $db = mysqli_connect('localhost','root','','a');

  if(isset($_POST['Store']))
  {
    $plantname          = $_POST['plantname'];
    $planttype          = $_POST['planttype'];
    $date               = $_POST['arrivaldate'];
    $quantity           = $_POST['quantity'];
	$storagelocation    = $_POST['storagelocation'];
    $timerequired       = $_POST['timerequired'];

    $sql= "INSERT INTO storing(plantname,planttype,arrivaldate,quantity,storagelocation,timerequired) 
            VALUES ('$plantname','$planttype','$date',$quantity,'$storagelocation','$timerequired')";

    $result = mysqli_query($db, $sql);
  }
  else if(isset($_POST['UpdateStoring']))
  {
    $plantname          = $_POST['plantname'];
    $planttype          = $_POST['planttype'];
    $date               = $_POST['arrivaldate'];
    $quantity           = $_POST['quantity'];
    $storagelocation    = $_POST['storagelocation'];
	$timerequired       = $_POST['timerequired'];

    $sql= "UPDATE storing SET timerequired='$timerequired' where plantname='$plantname' AND planttype='$planttype'";
    $result = mysqli_query($db, $sql);
	$sql= "UPDATE storing SET timerequired='$timerequired' where plantname='$plantname'";
    $result = mysqli_query($db, $sql);
	$sql= "UPDATE storing SET timerequired='$timerequired' where planttype='$planttype'";
    $result = mysqli_query($db, $sql);
    $sql= "UPDATE storing SET quantity='$quantity' where plantname='$plantname' AND planttype='$planttype'";
    $result = mysqli_query($db, $sql);
	$sql= "UPDATE storing SET quantity='$quantity' where plantname='$plantname'";
    $result = mysqli_query($db, $sql);
	$sql= "UPDATE storing SET quantity='$quantity' where planttype='$planttype'";
    $result = mysqli_query($db, $sql);
	$sql= "UPDATE storing SET storagelocation='$storagelocation' where plantname='$plantname' AND planttype='$planttype'";
    $result = mysqli_query($db, $sql);
	$sql= "UPDATE storing SET storagelocation='$storagelocation' where plantname='$plantname'";
    $result = mysqli_query($db, $sql);
	$sql= "UPDATE storing SET storagelocation='$storagelocation' where planttype='$planttype'";
    $result = mysqli_query($db, $sql);
  }
  else if(isset($_POST['DeleteStoring']))
  {
    $plantname          = $_POST['plantname'];
    $planttype          = $_POST['planttype'];
    $date               = $_POST['arrivaldate'];
    $quantity           = $_POST['quantity'];
    $storagelocation    = $_POST['storagelocation'];
	$timerequired       = $_POST['timerequired'];

    $sql= "DELETE FROM storing where plantname='$plantname' AND planttype='$planttype'";
    $result = mysqli_query($db, $sql);
	$sql= "DELETE FROM storing where plantname='$plantname'";
    $result = mysqli_query($db, $sql);
	$sql= "DELETE FROM storing where planttype='$planttype'";
    $result = mysqli_query($db, $sql);
  }
        header("Location: index.php");

 ?>
 
