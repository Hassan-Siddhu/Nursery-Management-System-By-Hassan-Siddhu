<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta http-equiv="x-ua-compatible" content="ie=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Nursery Database System</title>

    <link rel="stylesheet" href="sty.css" />
  </head>
<style>
.button {​​​​
    background-color:#367777;
    border-radius:28px;
    border:1px solid #215151;
    display:inline-block;
    cursor:pointer;
    color:#ffffff;
    font-family:Arial;
    font-size:13px;
    padding:12px 31px;
    text-decoration:none;
    text-shadow:0px 1px 0px #2f6627;
}​​​​
.button:hover {​​​​
    background-color:#009680;
}​​​​
.button:active {​​​​
    position:relative;
    top:1px;
}​​​​
.button1 {​​​​
    background-color:#000000;
    border-radius:28px;
    border:1px solid #215151;
    display:inline-block;
    cursor:pointer;
    color:#ffffff;
    font-family:Arial;
    font-size:13px;
    padding:12px 31px;
    text-decoration:none;
    text-shadow:0px 1px 0px #2f6627;
}​​​​
.button1:hover {​​​​
    background-color:#009680;
}​​​​
.button1:active {​​​​
    position:relative;
    top:1px;
}​​​​
input {​​​​
  background-color: white;
  color: white;
}​​​​
.header
{
  width:670px;
  height: 600px;
  margin:30px auto 0px;
  color: white;
  background: #5F9EA0;
  text-align : center;
  border: 1px solid #B0C4DE;
  border-bottom: none;
  border-radius: 10px 10px 10px 10px;
  padding: 20px;
}
.header
img
{
border: 1px solid #ddd;
  border-radius: 4px;
  padding: 5px;
  width: 250px;
}


</style>
<div class="header">
  <body>
    <h1>Nursery Record System</h1>
<img src="Nursery.jpeg">

        <div class="options">
        <a href="purchasing.php" class="button"><strong>Add\Update\Delete Plants Purchasing Details.</strong></a>
        </div>

        <div class="options">
        <a href="selling.php" class="button"><strong>Add\Update\Delete Plants Selling Details.</strong></a>
        </div>
      
        <div class="options" >
        <a href="breeding.php" class="button"><strong>Add\Update\Delete Breeding and Grooming Details.</strong></a>
      </div>
	  
        <div class="options">
        <a href="PurchasingDetails.php" class="button"><strong>Show Purchasing Details.</strong></a>
      </div>
	  
        <div class="options">
        <a href="SellingDetails.php" class="button"><strong>Show Selling Details.</strong></a>
      </div>
	  
        <div class="options">
        <a href="BreedingDetails.php" class="button"><strong>Show Breeding Details.</strong></a>
      </div>
	
        <div class="options">
        <a href="Searchfrompurchasing.php" class="button"><strong>Search Purchasing Records.</strong></a>
      </div>
	
        <div class="options">
        <a href="Searchfromselling.php" class="button"><strong>Search Selling Records.</strong></a>
      </div>
	
        <div class="options">
        <a href="Searchfromstoring.php" class="button"><strong>Search Storing Records.</strong></a>
      </div>

  </body>
  </div>
</html>