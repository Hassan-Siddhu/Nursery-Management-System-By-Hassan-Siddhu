<link rel="stylesheet" href="sty.css" />
<div class="header">
<style>
img
{
border: 1px solid #ddd;
  border-radius: 4px;
  padding: 5px;
  width: 250px;
}
</style>
<h1>Add Selling Details</h1>
<img src="Nursery.jpeg">
    <form action="server.php" method="post">
      <br>	<label for="orderno">Order No</label><br>
        <input type="number" name="orderno" id="orderno">
    <br>	<label for="plantname">Plant Name</label><br>
    	<input type="text" name="plantname" id="plantname">
    <br>	<label for="planttype">Plant Type</label><br>
    	<input type="text" name="planttype" id="planttype">
    <br>	<label for="price">Price</label><br>
    	<input type="text" name="price" id="price">
    <br>	<label for="quantity">Quantity</label><br>
    	<input type="number" name="quantity" id="quantity">
    <br>	<label for="sellingdate">Selling Date</label><br>
    	<input type="date" name="sellingdate" id="sellingdate">

      <br>
	  <br><input type="submit" id="Sell" name="Sell" value="Sell">
		  <input type="submit" id="UpdateSelling" name="UpdateSelling" value="UpdateSelling"> 
          <input type="submit" id="DeleteSelling" name="DeleteSelling" value="DeleteSelling"> 
    </form>

  <a href="index.php">Back to home</a>
    </div>