<html>
<head>
<style>
	table, th, td 
	{
		border: 2px solid black;
	}
	table 
	{
		width: 100%;
		border-collapse: collapse;
	}
	td 
	{
		text-align: center;
	}
	</style>
	<title> Search Data By Selling Date </title>
</head>
<body>
	<center>
	<h1> Search Data By Selling Date </h1>
	
	<div class="container">
	<form action="" method="POST">
	<input type="date" name="sellingdate" placeholder="Enter Selling Date">
	<input type="submit" name="Search" placeholder="Search By Selling Date">
	</form>
	<table>
	<link rel="stylesheet" href="sty.css" />
		<div class="table"> 
			<tr>
				<th>Order No</th>
				<th>Plant Name</th>
				<th>Plant Type</th>
				<th>Price</th>
				<th>Quantity</th>
				<th>Selling Date</th>
			</tr>
		</div>

			<?php
				$db = mysqli_connect('localhost','root','','a');

				if(isset($_POST['Search']))
				{
					$sellingdate      = $_POST['sellingdate'];
					$sql= "SELECT * FROM selling where sellingdate='$sellingdate'";
					$result = mysqli_query($db, $sql);
				while($row= mysqli_fetch_array($result))
				{
					?>
					    <tr>
					    <td> <?php echo $row['orderno'];?></td>
					    <td> <?php echo $row['plantname'];?></td>
					    <td> <?php echo $row['planttype'];?></td>
					    <td> <?php echo $row['price'];?></td>
					    <td> <?php echo $row['quantity'];?></td>
					    <td> <?php echo $row['sellingdate'];?></td>
					    </tr>
					
						<?php
				}
			}
			?>
	</table>
	</center>
</body>
<a href="Searchfromselling.php"> Back to Search </a>
</html>