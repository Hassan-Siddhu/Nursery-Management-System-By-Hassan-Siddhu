<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta http-equiv="x-ua-compatible" content="ie=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Nursery Database System</title>

    <link rel="stylesheet" href="sty.css" />
  </head>
<style>
.header
{
  width:670px;
  height: 600px;
  margin:30px auto 0px;
  color: white;
  background: #5F9EA0;
  text-align : center;
  border: 1px solid #B0C4DE;
  border-bottom: none;
  border-radius: 10px 10px 10px 10px;
  padding: 20px;
}
.header
img
{
border: 1px solid #ddd;
  border-radius: 4px;
  padding: 5px;
  width: 250px;
}
.options{
	
}

</style>
<div class="header">
  <body>
    <h1> Search Records from Selling </h1>
<img src="Nursery.jpeg">

      <li>
        <div class="options">
        <a href="searchdatabyorderno.php"><strong> Search Records By Order No.</strong></a>
        </div>
      </li>

      <li>
        <div class="options">
        <a href="searchdatabyplant(s).php"><strong> Search Records By Plant Name.</strong></a>
        </div>
      </li>

      <li>
        <div class="options">
        <a href="searchdatabytype(s).php"><strong> Search Records By Plant Type.</strong></a>
        </div>
      </li>

      <li>
        <div class="options">
        <a href="searchdatabysellingdate.php"><strong> Search Records By Purchasing Date.</strong></a>
        </div>
      </li>

  </body>
  <br><br>
  <a href="index.php"> Back to Index </a>
  </div>
  </html>